let historyImages = [];

async function generateImage() {
    const prompt = document.getElementById('prompt').value;
    const orientation = document.getElementById('orientation').value;
    const loading = document.getElementById('loading');
    const result = document.getElementById('result');
    const downloadBtn = document.getElementById('downloadBtn');

    loading.style.display = 'block';
    result.style.display = 'none';
    downloadBtn.style.display = 'none';

    try {
        const response = await fetch('/api/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt, size: orientation })
        });

        const data = await response.json();
        result.src = data.url;
        result.style.display = 'block';
        downloadBtn.style.display = 'block';

        historyImages.push(data.url);
        updateHistory();
    } catch (error) {
        alert('Error generating image');
    } finally {
        loading.style.display = 'none';
    }
}

function updateHistory() {
    const historyDiv = document.getElementById('history');
    historyDiv.innerHTML = '';
    historyImages.slice(-5).forEach(url => {
        const img = document.createElement('img');
        img.src = url;
        historyDiv.appendChild(img);
    });
}

function downloadImage() {
    const result = document.getElementById('result');
    const link = document.createElement('a');
    link.href = result.src;
    link.download = 'ai-generated-image.png';
    link.click();
}

function toggleTheme() {
    document.body.classList.toggle('light');
}